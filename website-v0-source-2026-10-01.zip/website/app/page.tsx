import type { Metadata } from "next";
import Link from "next/link";
import { CtaPair } from "@/components/cta-pair";
import { LandingIntro } from "@/components/landing-intro";
import { ProductPreview } from "@/components/product-preview";
import { ScrollStory } from "@/components/scroll-story";
import { OperationalPreview } from "@/components/operational-preview";
import { DemoBookingForm } from "@/components/demo-booking-form";
import { getSiteConfig } from "@/lib/site-config";

export const metadata: Metadata = { alternates: { canonical: "/" } };

export default function HomePage() {
  const { trialUrl } = getSiteConfig();
  return (
    <>
      <LandingIntro />
      <main id="main-content">
        <section className="marketing-hero" aria-labelledby="hero-heading">
          <div className="site-container marketing-hero-inner">
            <div className="marketing-hero-copy">
              <p className="hero-eyebrow">Governance, risk, and compliance</p>
              <h1 id="hero-heading" tabIndex={-1}>One place for the <em>work behind compliance.</em></h1>
              <p>Manage controls, evidence, policies, assets, vulnerabilities, and third-party risk in Verity. See what needs attention, who owns it, and how it supports your program.</p>
              <CtaPair light demoHref="#request-demo" />
            </div>
            <ProductPreview />
          </div>
        </section>

        <section className="editorial-bridge" aria-labelledby="bridge-title">
          <div className="site-container">
            <h2 id="bridge-title" className="reveal-block">A framework defines the goal. <em>Your records show the work.</em></h2>
            <p className="reveal-block">A control owner, an affected asset, a vendor assessment, an evidence review. Each has its own work to do, and a place in the same program.</p>
          </div>
        </section>

        <ScrollStory />

        <OperationalPreview />

        <section id="trust" className="accountability-section" aria-labelledby="trust-title">
          <div className="site-container accountability-layout">
            <div className="accountability-copy reveal-block">
              <span className="story-eyebrow">Accountability</span>
              <h2 id="trust-title">Every decision has a person behind it.</h2>
              <p>Permissions govern actions within each customer workspace. Changes, approvals, and review decisions retain their history so your team can follow how a record reached its current state.</p>
              <Link className="plain-link" href="/docs/12-settings-and-administration/">Read about workspace administration</Link>
            </div>
            <div className="history-visual reveal-block" role="img" aria-label="Illustrative activity history for a control, including ownership, evidence review, and a recorded decision">
              <div className="history-top"><span>Access reviews</span><span>Activity history</span></div>
              <div className="history-entry"><span className="history-point" /><div><strong>Control owner assigned</strong><p>Security team takes responsibility for quarterly reviews.</p></div><small>Owner</small></div>
              <div className="history-entry"><span className="history-point" /><div><strong>Evidence linked</strong><p>Quarterly access review attached to the control.</p></div><small>Evidence</small></div>
              <div className="history-entry"><span className="history-point" /><div><strong>Review decision recorded</strong><p>The decision and its reason remain in the activity history.</p></div><small>Review</small></div>
            </div>
          </div>
        </section>

        <section className="guide-section" aria-labelledby="guide-title">
          <div className="site-container guide-layout">
            <div className="reveal-block">
              <span className="story-eyebrow">Public user guide</span>
              <h2 id="guide-title">Learn the workflow before you create a workspace.</h2>
              <p>Read the complete guide for setup, controls, evidence, risks, vendors, and administration. It includes real task walkthroughs and product screenshots.</p>
              <Link className="button button-outline" href="/docs/">Open the user guide</Link>
            </div>
            <nav className="guide-chapters reveal-block" aria-label="Popular guide chapters">
              <Link href="/docs/01-getting-started/"><span>01</span><strong>Getting started</strong></Link>
              <Link href="/docs/03-frameworks-and-controls/"><span>03</span><strong>Frameworks and controls</strong></Link>
              <Link href="/docs/04-evidence/"><span>04</span><strong>Evidence</strong></Link>
              <Link href="/docs/07-risks/"><span>07</span><strong>Risks</strong></Link>
              <Link href="/docs/08-vendors/"><span>08</span><strong>Vendors</strong></Link>
            </nav>
          </div>
        </section>

        <section className="questions-section" aria-labelledby="questions-title">
          <div className="site-container questions-layout">
            <div className="questions-heading reveal-block"><span className="story-eyebrow">FAQ</span><h2 id="questions-title">Questions before you start?</h2><p>A few details that matter when choosing a GRC workspace.</p></div>
            <div className="questions-list reveal-block">
              <details><summary>What can our team manage in Verity today?</summary><p>Controls, evidence, policies, tasks, risk, vendor engagements, assets, and vulnerability findings each have their own workflow. The public <Link href="/docs/">user guide</Link> shows how they work.</p></details>
              <details><summary>Which frameworks are available?</summary><p>The shipped control library is SOC 2. The framework model can accept additional libraries, but ISO 27001 and other framework content are planned rather than available today.</p></details>
              <details><summary>Are business continuity and VantageMDM included?</summary><p>Business continuity workflows are planned for Verity. VantageMDM is separate software and is not part of the Verity workspace.</p></details>
              <details><summary>Do we need integrations to get started?</summary><p>No. Teams can assign controls, upload evidence, import vulnerability findings, and manage vendors and risks directly. GitHub is the first live connector; other connections marked “Soon” are planned.</p></details>
              <details><summary>Who approves evidence and risk decisions?</summary><p>People do. Suggestions and AI drafts require review. The responsible person makes the formal decision, and the record keeps its history.</p></details>
              <details><summary>Can we book a demo here?</summary><p>You can explore the form and choose a preferred date below. Scheduling is a preview until a booking service is connected; it does not send details or reserve a time yet.</p></details>
            </div>
          </div>
        </section>

        <section className="closing-section" aria-labelledby="closing-title">
          <div className="site-container closing-inner reveal-block">
            <span className="closing-eyebrow">Across the program</span>
            <h2 id="closing-title">The answer should be in the record.</h2>
            <p>Which asset is affected? Who approved a vendor? What evidence supports a control? Keep the response close to the work.</p>
            <a className="button button-white" href={trialUrl}>Start trial</a>
          </div>
        </section>

        <section id="request-demo" className="apply-section" aria-labelledby="apply-title">
          <div className="site-container apply-inner">
            <div className="apply-heading reveal-block"><span className="story-eyebrow">See Verity with your team</span><h2 id="apply-title">Tell us where your GRC work gets stuck.</h2><p>Tell us which areas you want to see and choose a preferred date. Scheduling is a preview for now, so this form does not send your details or reserve a time.</p></div>
            <DemoBookingForm />
          </div>
        </section>
      </main>
    </>
  );
}
