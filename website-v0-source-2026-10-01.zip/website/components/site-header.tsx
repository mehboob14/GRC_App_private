import Link from "next/link";
import { Brand } from "./brand";
import { getSiteConfig } from "@/lib/site-config";
import { MobileNav } from "./mobile-nav";

export function SiteHeader() {
  const config = getSiteConfig();
  return (
    <header className="site-header">
      <div className="site-container header-inner">
        <Brand />
        <nav className="desktop-nav" aria-label="Main navigation">
          <Link href="/#platform">Platform</Link>
          <Link href="/#coverage">What it covers</Link>
          <Link href="/docs/">Documentation</Link>
        </nav>
        <div className="header-actions">
          <a className="sign-in-link" href={config.signInUrl}>Sign in</a>
          <Link className="button button-small button-dark" href="/#request-demo">Book a demo</Link>
        </div>
        <MobileNav signInUrl={config.signInUrl} trialUrl={config.trialUrl} />
      </div>
    </header>
  );
}
